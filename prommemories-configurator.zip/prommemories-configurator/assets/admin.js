(function(){
  'use strict';

  function uid(prefix){ return prefix + '-' + Math.random().toString(36).slice(2,9); }
  function czk(n){ n = Number(n)||0; return n.toLocaleString('cs-CZ') + ' Kč'; }
  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  document.addEventListener('DOMContentLoaded', function(){
    var root = document.getElementById('pmc-admin-root');
    if(!root || typeof pmcAdminData === 'undefined') return;

    var state = JSON.parse(JSON.stringify(pmcAdminData.config));
    if(!Array.isArray(state.discountTiers)) state.discountTiers = [];
    var settings = JSON.parse(JSON.stringify(pmcAdminData.settings));

    root.innerHTML =
      '<div class="pmc-app">' +
        '<div class="pmc-editor-toolbar">' +
          '<button type="button" class="pmc-btn pmc-btn-gold pmc-btn-save-all" data-save-all>Uložit změny</button>' +
          '<span class="pmc-save-flag"></span>' +
          '<div class="pmc-update-check-row">' +
            '<span class="pmc-kc">Nainstalovaná verze: <strong>' + escapeHtml(pmcAdminData.currentVersion || '?') + '</strong></span>' +
            '<button type="button" class="pmc-btn" data-check-update>Zkontrolovat aktualizace</button>' +
            '<span class="pmc-update-result"></span>' +
          '</div>' +
          '<button type="button" class="pmc-btn pmc-btn-ghost" data-reset>Obnovit výchozí ceník</button>' +
        '</div>' +

        '<div class="pmc-edit-section" id="pmc-settings-card">' +
          '<div class="pmc-edit-section-head"><span class="pmc-section-title">Nastavení</span><span class="pmc-section-hint">kam se posílají poptávky z konfigurátoru</span></div>' +
          '<div class="pmc-settings-row">' +
            '<label class="pmc-kc" style="min-width:130px;">E-mail pro poptávky</label>' +
            '<input type="email" data-target-email value="' + escapeHtml(settings.targetEmail || '') + '">' +
          '</div>' +
        '</div>' +

        '<div class="pmc-edit-section" id="pmc-theme-card">' +
          '<div class="pmc-edit-section-head"><span class="pmc-section-title">Vzhled konfigurátoru</span><span class="pmc-section-hint">barvy pro veřejnou stránku — editor sám zůstává neutrální</span></div>' +
          '<div class="pmc-theme-grid" data-theme-grid></div>' +
          '<div class="pmc-theme-preview-wrap">' +
            '<p class="pmc-kc" style="margin:0 0 8px;">Náhled, jak to uvidí návštěvník webu:</p>' +
            '<div class="pmc-theme-preview" data-theme-preview>' +
              '<div class="pmc-option selected" style="pointer-events:none;cursor:default;">' +
                '<span class="pmc-option-left"><span class="pmc-option-text"><span class="pmc-option-name">Ukázková položka</span><span class="pmc-option-desc">Takhle bude vypadat popis balíčku.</span></span></span>' +
                '<span class="pmc-option-price">5 000 Kč</span>' +
              '</div>' +
              '<div class="pmc-ticket-total" style="padding:12px 2px 0;"><span class="t-label">Celkem</span><span class="t-value">12 000 Kč</span></div>' +
            '</div>' +
          '</div>' +
        '</div>' +

        '<div class="pmc-edit-section" id="pmc-labels-card">' +
          '<div class="pmc-edit-section-head"><span class="pmc-section-title">Texty rozhraní</span><span class="pmc-section-hint">veškeré popisky, tlačítka a hlášky v konfigurátoru</span></div>' +
          '<div class="pmc-labels-grid" data-labels-grid></div>' +
        '</div>' +

        '<div class="pmc-edit-section" id="pmc-discount-card">' +
          '<div class="pmc-edit-section-head">' +
            '<span class="pmc-section-title">Množstevní slevy</span>' +
            '<span class="pmc-section-hint">sleva při objednání více služeb najednou</span>' +
          '</div>' +
          '<div class="pmc-edit-items" data-tiers-wrap></div>' +
        '</div>' +
        '<div data-sections-wrap></div>' +
        '<div class="pmc-add-section-wrap"><button type="button" class="pmc-btn pmc-btn-gold" data-add-section>+ Přidat sekci</button></div>' +
      '</div>';

    var flag = root.querySelector('.pmc-save-flag');
    var sectionsWrap = root.querySelector('[data-sections-wrap]');
    var tiersWrap = root.querySelector('[data-tiers-wrap]');
    var themeGrid = root.querySelector('[data-theme-grid]');
    var labelsGrid = root.querySelector('[data-labels-grid]');
    var updateResult = root.querySelector('.pmc-update-result');

    var THEME_LABELS = {
      bg: 'Pozadí', bgPanel: 'Karty', bgPanelAlt: 'Karty (hover)',
      ivory: 'Text', slate: 'Tlumený text', slateDim: 'Slabý text', gold: 'Výchozí akcent'
    };

    function hexToParts(value){
      // Accepts #rgb, #rrggbb, #rrggbbaa. Returns { hex6, alphaPct }.
      var v = (value || '#000000').replace('#', '');
      if(v.length === 3){ v = v.split('').map(function(c){ return c + c; }).join(''); }
      var hex6 = '#' + v.slice(0, 6).padEnd(6, '0');
      var alphaPct = 100;
      if(v.length === 8){
        alphaPct = Math.round((parseInt(v.slice(6, 8), 16) / 255) * 100);
      }
      return { hex6: hex6, alphaPct: alphaPct };
    }

    function partsToValue(hex6, alphaPct){
      if(alphaPct >= 100) return hex6;
      var alphaHex = Math.round((alphaPct / 100) * 255).toString(16).padStart(2, '0');
      return hex6 + alphaHex;
    }

    function renderThemeGrid(){
      themeGrid.innerHTML = '';
      Object.keys(THEME_LABELS).forEach(function(key){
        var parts = hexToParts(settings.theme[key]);
        var field = document.createElement('div');
        field.className = 'pmc-theme-field';
        field.innerHTML =
          '<span>' + THEME_LABELS[key] + '</span>' +
          '<div class="swatch-row">' +
            '<input type="color" value="' + parts.hex6 + '" data-theme-color="' + key + '">' +
            '<input type="text" value="' + escapeHtml(settings.theme[key] || '') + '" data-theme-text="' + key + '">' +
          '</div>' +
          '<div class="swatch-row pmc-opacity-row">' +
            '<input type="range" min="0" max="100" value="' + parts.alphaPct + '" data-theme-alpha="' + key + '">' +
            '<span class="pmc-kc" data-alpha-label="' + key + '">' + parts.alphaPct + '%</span>' +
          '</div>';
        themeGrid.appendChild(field);
      });

      function updateFromParts(key){
        var colorInput = themeGrid.querySelector('[data-theme-color="' + key + '"]');
        var alphaInput = themeGrid.querySelector('[data-theme-alpha="' + key + '"]');
        var textInput = themeGrid.querySelector('[data-theme-text="' + key + '"]');
        var alphaLabel = themeGrid.querySelector('[data-alpha-label="' + key + '"]');
        var value = partsToValue(colorInput.value, Number(alphaInput.value));
        settings.theme[key] = value;
        textInput.value = value;
        alphaLabel.textContent = alphaInput.value + '%';
        applyLivePreview();
        scheduleSaveSettings();
      }

      themeGrid.querySelectorAll('[data-theme-color]').forEach(function(el){
        el.addEventListener('input', function(e){ updateFromParts(e.target.dataset.themeColor); });
      });
      themeGrid.querySelectorAll('[data-theme-alpha]').forEach(function(el){
        el.addEventListener('input', function(e){ updateFromParts(e.target.dataset.themeAlpha); });
      });
      themeGrid.querySelectorAll('[data-theme-text]').forEach(function(el){
        el.addEventListener('change', function(e){
          var key = e.target.dataset.themeText;
          var val = e.target.value.trim();
          if(!/^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6}|[0-9a-fA-F]{8})$/.test(val)){ e.target.value = settings.theme[key]; return; }
          settings.theme[key] = val;
          var parts = hexToParts(val);
          var colorInput = themeGrid.querySelector('[data-theme-color="' + key + '"]');
          var alphaInput = themeGrid.querySelector('[data-theme-alpha="' + key + '"]');
          var alphaLabel = themeGrid.querySelector('[data-alpha-label="' + key + '"]');
          if(colorInput) colorInput.value = parts.hex6;
          if(alphaInput) alphaInput.value = parts.alphaPct;
          if(alphaLabel) alphaLabel.textContent = parts.alphaPct + '%';
          applyLivePreview();
          scheduleSaveSettings();
        });
      });
    }

    var LABEL_GROUPS = [
      { title: 'Hlavička', fields: [
        ['headerEyebrow', 'Malý nadpis nahoře'],
        ['headerTitle', 'Hlavní nadpis']
      ]},
      { title: 'Cenová nabídka', fields: [
        ['ticketEyebrow', 'Malý nadpis nabídky'],
        ['ticketTitle', 'Nadpis nabídky'],
        ['emptyText', 'Text když nic není vybráno'],
        ['subtotalLabel', 'Popisek mezisoučtu'],
        ['discountLabel', 'Popisek slevy'],
        ['totalLabel', 'Popisek celkové ceny'],
        ['sendButtonLabel', 'Text tlačítka odeslání'],
        ['noSelectionTitle', 'Tooltip při prázdném výběru']
      ]},
      { title: 'Sekce a volby', fields: [
        ['noneOptionLabel', 'Text volby "nic nevybráno"'],
        ['packagesHint', 'Nápověda u sekcí s balíčky'],
        ['customHint', 'Nápověda u sekcí s vlastní cenou'],
        ['includePrefix', 'Předpona u zaškrtávacího pole (např. "Zahrnout")'],
        ['unitLabel', 'Zkratka měny']
      ]},
      { title: 'Formulář poptávky', fields: [
        ['modalTitle', 'Nadpis formuláře'],
        ['modalTotalPrefix', 'Text před celkovou cenou'],
        ['modalNameLabel', 'Popisek pole Jméno'],
        ['modalEmailLabel', 'Popisek pole E-mail'],
        ['modalPhoneLabel', 'Popisek pole Telefon'],
        ['modalCancelLabel', 'Text tlačítka Zrušit'],
        ['modalSendLabel', 'Text tlačítka Odeslat'],
        ['modalValidationError', 'Chyba při špatně vyplněných údajích'],
        ['modalSendingText', 'Text během odesílání'],
        ['modalSuccessText', 'Text po úspěšném odeslání'],
        ['modalGenericError', 'Obecná chybová hláška']
      ]}
    ];

    function renderLabelsGrid(){
      labelsGrid.innerHTML = '';
      LABEL_GROUPS.forEach(function(group){
        var groupEl = document.createElement('div');
        groupEl.className = 'pmc-labels-group';
        groupEl.innerHTML = '<h4 class="pmc-labels-group-title">' + escapeHtml(group.title) + '</h4>';
        group.fields.forEach(function(pair){
          var key = pair[0], hint = pair[1];
          var field = document.createElement('label');
          field.className = 'pmc-label-field';
          field.innerHTML =
            '<span>' + escapeHtml(hint) + '</span>' +
            '<input type="text" value="' + escapeHtml(settings.labels[key] || '') + '" data-label-key="' + key + '">';
          groupEl.appendChild(field);
        });
        labelsGrid.appendChild(groupEl);
      });

      labelsGrid.querySelectorAll('[data-label-key]').forEach(function(el){
        el.addEventListener('input', function(e){
          settings.labels[e.target.dataset.labelKey] = e.target.value;
          scheduleSaveSettings();
        });
      });
    }

    function applyLivePreview(){
      var preview = root.querySelector('[data-theme-preview]');
      if(!preview) return;
      var map = { bg:'--pmc-bg', bgPanel:'--pmc-bg-panel', bgPanelAlt:'--pmc-bg-panel-alt', ivory:'--pmc-ivory', slate:'--pmc-slate', slateDim:'--pmc-slate-dim', gold:'--pmc-gold' };
      Object.keys(map).forEach(function(key){
        preview.style.setProperty(map[key], settings.theme[key]);
      });
    }

    var dirty = false;
    function markDirty(){
      dirty = true;
      flag.textContent = ' Neuložené změny';
      flag.className = 'pmc-save-flag dirty';
    }

    function scheduleSaveSettings(){ markDirty(); }

    function persistSettings(){
      return fetch(pmcAdminData.settingsRestUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': pmcAdminData.nonce },
        body: JSON.stringify(settings)
      }).then(function(res){
        if(!res.ok) throw new Error('settings save failed');
        return res.json();
      });
    }

    root.querySelector('[data-target-email]').addEventListener('input', function(e){
      settings.targetEmail = e.target.value;
      scheduleSaveSettings();
    });

    root.querySelector('[data-check-update]').addEventListener('click', function(){
      updateResult.textContent = 'Kontroluji…';
      updateResult.className = 'pmc-update-result';
      var body = new URLSearchParams();
      body.set('action', 'pmc_check_update');
      body.set('nonce', pmcAdminData.checkNonce);
      fetch(pmcAdminData.ajaxUrl, { method: 'POST', body: body })
        .then(function(res){ return res.json(); })
        .then(function(res){
          if(!res.success){
            updateResult.textContent = 'Kontrolu se nepodařilo provést.';
            updateResult.className = 'pmc-update-result error';
            return;
          }
          var d = res.data;
          if(d.error){
            updateResult.textContent = 'Nepodařilo se načíst update.json z GitHubu.';
            updateResult.className = 'pmc-update-result error';
          } else if(d.available){
            updateResult.textContent = 'K dispozici je nová verze ' + d.latest + ' (aktuální: ' + d.current + '). Aktualizuj v sekci Pluginy.';
            updateResult.className = 'pmc-update-result available';
          } else {
            updateResult.textContent = 'Máš nejnovější verzi (' + d.current + ').';
            updateResult.className = 'pmc-update-result ok';
          }
        })
        .catch(function(){
          updateResult.textContent = 'Kontrolu se nepodařilo provést.';
          updateResult.className = 'pmc-update-result error';
        });
    });

    function scheduleSave(){ markDirty(); }

    function persistConfig(){
      return fetch(pmcAdminData.restUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': pmcAdminData.nonce },
        body: JSON.stringify(state)
      }).then(function(res){
        if(!res.ok) throw new Error('config save failed');
        return res.json();
      });
    }

    root.querySelector('[data-save-all]').addEventListener('click', function(){
      flag.textContent = ' Ukládám…';
      flag.className = 'pmc-save-flag';
      Promise.all([ persistConfig(), persistSettings() ]).then(function(){
        dirty = false;
        flag.textContent = ' Uloženo ✓';
        flag.className = 'pmc-save-flag ok';
        setTimeout(function(){ flag.textContent = ''; flag.className = 'pmc-save-flag'; }, 1800);
      }).catch(function(){
        flag.textContent = ' Uložení selhalo, zkus to znovu.';
        flag.className = 'pmc-save-flag error';
      });
    });

    window.addEventListener('beforeunload', function(e){
      if(dirty){ e.preventDefault(); e.returnValue = ''; }
    });

    /* ---------- discount tiers ---------- */

    function renderTiers(){
      tiersWrap.innerHTML = '';
      if(!state.discountTiers.length){
        var p = document.createElement('p');
        p.className = 'pmc-tier-empty';
        p.textContent = 'Zatím žádné slevové úrovně — přidej první níže.';
        tiersWrap.appendChild(p);
      }
      state.discountTiers.slice().sort(function(a,b){ return a.minCount - b.minCount; }).forEach(function(tier){
        var row = document.createElement('div');
        row.className = 'pmc-tier-row';
        row.innerHTML =
          '<span class="tf">Od</span>' +
          '<input type="number" min="2" step="1" value="' + tier.minCount + '" data-tmin="' + tier.id + '">' +
          '<span class="tf">služeb sleva</span>' +
          '<input type="number" min="0" step="1" value="' + tier.value + '" data-tval="' + tier.id + '">' +
          '<select data-ttype="' + tier.id + '">' +
            '<option value="percent"' + (tier.type === 'percent' ? ' selected' : '') + '>%</option>' +
            '<option value="fixed"' + (tier.type === 'fixed' ? ' selected' : '') + '>Kč</option>' +
          '</select>' +
          '<button type="button" class="pmc-btn pmc-btn-ghost pmc-btn-sm" data-tdel="' + tier.id + '">Smazat</button>';
        tiersWrap.appendChild(row);
      });
      var addRow = document.createElement('div');
      addRow.className = 'pmc-add-item-row';
      addRow.innerHTML = '<button type="button" class="pmc-btn pmc-btn-sm" data-add-tier>+ Přidat úroveň slevy</button>';
      tiersWrap.appendChild(addRow);

      tiersWrap.querySelectorAll('[data-tmin]').forEach(function(el){
        el.addEventListener('input', function(e){
          var t = state.discountTiers.filter(function(t){ return t.id === e.target.dataset.tmin; })[0];
          t.minCount = Math.max(2, Number(e.target.value) || 2);
          scheduleSave();
        });
      });
      tiersWrap.querySelectorAll('[data-tval]').forEach(function(el){
        el.addEventListener('input', function(e){
          var t = state.discountTiers.filter(function(t){ return t.id === e.target.dataset.tval; })[0];
          t.value = Number(e.target.value) || 0;
          scheduleSave();
        });
      });
      tiersWrap.querySelectorAll('[data-ttype]').forEach(function(el){
        el.addEventListener('change', function(e){
          var t = state.discountTiers.filter(function(t){ return t.id === e.target.dataset.ttype; })[0];
          t.type = e.target.value;
          scheduleSave();
        });
      });
      tiersWrap.querySelectorAll('[data-tdel]').forEach(function(el){
        el.addEventListener('click', function(e){
          state.discountTiers = state.discountTiers.filter(function(t){ return t.id !== e.target.dataset.tdel; });
          scheduleSave(); renderTiers();
        });
      });
      var addTierBtn = tiersWrap.querySelector('[data-add-tier]');
      if(addTierBtn){
        addTierBtn.addEventListener('click', function(){
          var maxMin = state.discountTiers.reduce(function(m,t){ return Math.max(m, t.minCount); }, 1);
          state.discountTiers.push({ id: uid('tier'), minCount: maxMin + 1, type: 'percent', value: 5 });
          scheduleSave(); renderTiers();
        });
      }
    }

    /* ---------- sections / items / breakdown ---------- */

    function buildEditItem(sec, sIdx, item, iIdx){
      var bdSum = (item.breakdown || []).reduce(function(a,b){ return a + (Number(b.amount) || 0); }, 0);
      var margin = (Number(item.price) || 0) - bdSum;
      var div = document.createElement('div');
      div.className = 'pmc-edit-item';
      div.innerHTML =
        '<div class="pmc-edit-item-row">' +
          '<input class="pmc-item-name" value="' + escapeHtml(item.name) + '" data-iname="' + sIdx + ':' + iIdx + '">' +
          '<input type="number" class="pmc-item-price" min="0" step="100" value="' + item.price + '" data-iprice="' + sIdx + ':' + iIdx + '">' +
          '<span class="pmc-kc">Kč</span>' +
          '<button type="button" class="pmc-btn pmc-btn-ghost pmc-btn-sm" data-delitem="' + sIdx + ':' + iIdx + '">Smazat</button>' +
        '</div>' +
        '<div class="pmc-desc-toolbar">' +
          '<button type="button" class="pmc-fmt-btn" data-fmt-bold="' + sIdx + ':' + iIdx + '" title="Tučně"><strong>B</strong></button>' +
          '<button type="button" class="pmc-fmt-btn" data-fmt-list="' + sIdx + ':' + iIdx + '" title="Přepnout na odrážky/odstavec">≡ Odrážky</button>' +
        '</div>' +
        '<textarea class="pmc-item-desc" placeholder="Popis balíčku (zobrazí se v konfigurátoru)" data-idesc="' + sIdx + ':' + iIdx + '">' + escapeHtml(item.desc || '') + '</textarea>' +
        '<div class="pmc-breakdown" data-bdwrap="' + sIdx + ':' + iIdx + '">' +
          (item.breakdown || []).map(function(b, bIdx){
            return '<div class="pmc-breakdown-row">' +
              '<input class="pmc-bd-label" value="' + escapeHtml(b.label) + '" data-bdlabel="' + sIdx + ':' + iIdx + ':' + bIdx + '" placeholder="např. Kameraman 1">' +
              '<input type="number" class="pmc-bd-amount" min="0" step="100" value="' + b.amount + '" data-bdamount="' + sIdx + ':' + iIdx + ':' + bIdx + '">' +
              '<span class="pmc-kc">Kč</span>' +
              '<button type="button" class="pmc-btn pmc-btn-ghost pmc-btn-sm" data-delbd="' + sIdx + ':' + iIdx + ':' + bIdx + '">×</button>' +
            '</div>';
          }).join('') +
          '<button type="button" class="pmc-btn pmc-btn-sm" data-addbd="' + sIdx + ':' + iIdx + '">+ Položka nákladu</button>' +
          '<div class="pmc-breakdown-foot">' +
            '<span class="pmc-kc">Náklady celkem: ' + czk(bdSum) + '</span>' +
            '<span class="' + (margin >= 0 ? 'pmc-margin-pos' : 'pmc-margin-neg') + '">Marže: ' + czk(margin) + '</span>' +
          '</div>' +
        '</div>';
      return div;
    }

    function renderSections(){
      sectionsWrap.innerHTML = '';

      state.sections.forEach(function(sec, sIdx){
        var card = document.createElement('div');
        card.className = 'pmc-edit-section';

        var head = document.createElement('div');
        head.className = 'pmc-edit-section-head';
        head.innerHTML =
          '<input class="pmc-sec-name" value="' + escapeHtml(sec.name) + '" data-sname="' + sIdx + '">' +
          '<div class="pmc-sec-color-wrap">' +
            '<input type="color" value="' + (sec.color || '#2cc6e6') + '" data-scolor="' + sIdx + '" title="Barva sekce">' +
            '<button type="button" class="pmc-sec-color-clear" data-scolor-clear="' + sIdx + '" title="Zrušit vlastní barvu">×</button>' +
          '</div>' +
          '<select class="pmc-sec-type" data-stype="' + sIdx + '">' +
            '<option value="packages"' + (sec.type === 'packages' ? ' selected' : '') + '>Balíčky (výběr z nabídky)</option>' +
            '<option value="custom"' + (sec.type === 'custom' ? ' selected' : '') + '>Individuální cena</option>' +
          '</select>' +
          '<button type="button" class="pmc-btn pmc-btn-ghost pmc-btn-sm" data-delsec="' + sIdx + '">Smazat sekci</button>';
        card.appendChild(head);

        var itemsWrap = document.createElement('div');
        itemsWrap.className = 'pmc-edit-items';

        if(sec.type === 'custom'){
          var row = document.createElement('div');
          row.className = 'pmc-edit-item';
          row.innerHTML =
            '<div class="pmc-edit-item-row">' +
              '<span class="pmc-kc">Výchozí navrhovaná cena, kterou půjde v konfigurátoru přebít:</span>' +
              '<input type="number" class="pmc-item-price" min="0" step="100" value="' + (sec.defaultPrice || 0) + '" data-defprice="' + sIdx + '">' +
              '<span class="pmc-kc">Kč</span>' +
            '</div>' +
            '<div class="pmc-desc-toolbar">' +
              '<button type="button" class="pmc-fmt-btn" data-fmt-bold-sec="' + sIdx + '" title="Tučně"><strong>B</strong></button>' +
              '<button type="button" class="pmc-fmt-btn" data-fmt-list-sec="' + sIdx + '" title="Přepnout na odrážky/odstavec">≡ Odrážky</button>' +
            '</div>' +
            '<textarea class="pmc-item-desc" placeholder="Popis sekce (zobrazí se v konfigurátoru)" data-secdesc="' + sIdx + '">' + escapeHtml(sec.desc || '') + '</textarea>';
          itemsWrap.appendChild(row);
        } else {
          (sec.items || []).forEach(function(item, iIdx){
            itemsWrap.appendChild(buildEditItem(sec, sIdx, item, iIdx));
          });
          var addRow = document.createElement('div');
          addRow.className = 'pmc-add-item-row';
          addRow.innerHTML = '<button type="button" class="pmc-btn pmc-btn-sm" data-additem="' + sIdx + '">+ Přidat balíček</button>';
          itemsWrap.appendChild(addRow);
        }

        card.appendChild(itemsWrap);
        sectionsWrap.appendChild(card);
      });

      attachSectionEvents();
    }

    function applyBoldFormat(textarea){
      var start = textarea.selectionStart, end = textarea.selectionEnd;
      var val = textarea.value;
      if(start === end){
        textarea.value = val.slice(0, start) + '****' + val.slice(end);
        textarea.selectionStart = textarea.selectionEnd = start + 2;
      } else {
        var selected = val.slice(start, end);
        textarea.value = val.slice(0, start) + '**' + selected + '**' + val.slice(end);
        textarea.selectionStart = start;
        textarea.selectionEnd = end + 4;
      }
      textarea.dispatchEvent(new Event('input'));
      textarea.focus();
    }

    function applyListFormat(textarea){
      var start = textarea.selectionStart, end = textarea.selectionEnd;
      var val = textarea.value;
      var lineStart = val.lastIndexOf('\n', start - 1) + 1;
      var lineEnd = val.indexOf('\n', end);
      if(lineEnd === -1) lineEnd = val.length;
      var block = val.slice(lineStart, lineEnd);
      var lines = block.split('\n');
      var contentLines = lines.filter(function(l){ return l.trim() !== ''; });
      var allBulleted = contentLines.length > 0 && contentLines.every(function(l){ return /^\s*-\s/.test(l); });
      var newLines = lines.map(function(l){
        if(l.trim() === '') return l;
        if(allBulleted){ return l.replace(/^(\s*)-\s?/, '$1'); }
        return /^\s*-\s/.test(l) ? l : '- ' + l.replace(/^\s+/, '');
      });
      var newBlock = newLines.join('\n');
      textarea.value = val.slice(0, lineStart) + newBlock + val.slice(lineEnd);
      textarea.dispatchEvent(new Event('input'));
      textarea.focus();
    }

    function attachSectionEvents(){
      sectionsWrap.querySelectorAll('[data-sname]').forEach(function(el){
        el.addEventListener('input', function(e){
          state.sections[+e.target.dataset.sname].name = e.target.value;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-scolor]').forEach(function(el){
        el.addEventListener('input', function(e){
          state.sections[+e.target.dataset.scolor].color = e.target.value;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-scolor-clear]').forEach(function(el){
        el.addEventListener('click', function(e){
          var idx = +e.target.dataset.scolorClear;
          state.sections[idx].color = '';
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-stype]').forEach(function(el){
        el.addEventListener('change', function(e){
          var sec = state.sections[+e.target.dataset.stype];
          sec.type = e.target.value;
          if(sec.type === 'custom' && sec.defaultPrice === undefined) sec.defaultPrice = 0;
          if(sec.type === 'packages' && !sec.items) sec.items = [];
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-delsec]').forEach(function(el){
        el.addEventListener('click', function(e){
          var idx = +e.target.dataset.delsec;
          if(confirm('Smazat sekci "' + state.sections[idx].name + '"?')){
            state.sections.splice(idx, 1);
            scheduleSave(); renderSections();
          }
        });
      });
      sectionsWrap.querySelectorAll('[data-defprice]').forEach(function(el){
        el.addEventListener('input', function(e){
          state.sections[+e.target.dataset.defprice].defaultPrice = Number(e.target.value) || 0;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-secdesc]').forEach(function(el){
        el.addEventListener('input', function(e){
          state.sections[+e.target.dataset.secdesc].desc = e.target.value;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-fmt-bold-sec]').forEach(function(el){
        el.addEventListener('click', function(e){
          var idx = e.target.closest('[data-fmt-bold-sec]').dataset.fmtBoldSec;
          applyBoldFormat(sectionsWrap.querySelector('[data-secdesc="' + idx + '"]'));
        });
      });
      sectionsWrap.querySelectorAll('[data-fmt-list-sec]').forEach(function(el){
        el.addEventListener('click', function(e){
          var idx = e.target.closest('[data-fmt-list-sec]').dataset.fmtListSec;
          applyListFormat(sectionsWrap.querySelector('[data-secdesc="' + idx + '"]'));
        });
      });
      sectionsWrap.querySelectorAll('[data-additem]').forEach(function(el){
        el.addEventListener('click', function(e){
          var sIdx = +e.target.dataset.additem;
          state.sections[sIdx].items.push({ id: uid('item'), name: 'Nová položka', price: 0, desc: '', breakdown: [] });
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-iname]').forEach(function(el){
        el.addEventListener('input', function(e){
          var p = e.target.dataset.iname.split(':').map(Number);
          state.sections[p[0]].items[p[1]].name = e.target.value;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-iprice]').forEach(function(el){
        el.addEventListener('input', function(e){
          var p = e.target.dataset.iprice.split(':').map(Number);
          state.sections[p[0]].items[p[1]].price = Number(e.target.value) || 0;
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-idesc]').forEach(function(el){
        el.addEventListener('input', function(e){
          var p = e.target.dataset.idesc.split(':').map(Number);
          state.sections[p[0]].items[p[1]].desc = e.target.value;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-fmt-bold]').forEach(function(el){
        el.addEventListener('click', function(e){
          var key = e.target.closest('[data-fmt-bold]').dataset.fmtBold;
          applyBoldFormat(sectionsWrap.querySelector('[data-idesc="' + key + '"]'));
        });
      });
      sectionsWrap.querySelectorAll('[data-fmt-list]').forEach(function(el){
        el.addEventListener('click', function(e){
          var key = e.target.closest('[data-fmt-list]').dataset.fmtList;
          applyListFormat(sectionsWrap.querySelector('[data-idesc="' + key + '"]'));
        });
      });
      sectionsWrap.querySelectorAll('[data-delitem]').forEach(function(el){
        el.addEventListener('click', function(e){
          var p = e.target.dataset.delitem.split(':').map(Number);
          state.sections[p[0]].items.splice(p[1], 1);
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-addbd]').forEach(function(el){
        el.addEventListener('click', function(e){
          var p = e.target.dataset.addbd.split(':').map(Number);
          if(!state.sections[p[0]].items[p[1]].breakdown) state.sections[p[0]].items[p[1]].breakdown = [];
          state.sections[p[0]].items[p[1]].breakdown.push({ label: 'Nová položka nákladu', amount: 0 });
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-bdlabel]').forEach(function(el){
        el.addEventListener('input', function(e){
          var p = e.target.dataset.bdlabel.split(':').map(Number);
          state.sections[p[0]].items[p[1]].breakdown[p[2]].label = e.target.value;
          scheduleSave();
        });
      });
      sectionsWrap.querySelectorAll('[data-bdamount]').forEach(function(el){
        el.addEventListener('input', function(e){
          var p = e.target.dataset.bdamount.split(':').map(Number);
          state.sections[p[0]].items[p[1]].breakdown[p[2]].amount = Number(e.target.value) || 0;
          scheduleSave(); renderSections();
        });
      });
      sectionsWrap.querySelectorAll('[data-delbd]').forEach(function(el){
        el.addEventListener('click', function(e){
          var p = e.target.dataset.delbd.split(':').map(Number);
          state.sections[p[0]].items[p[1]].breakdown.splice(p[2], 1);
          scheduleSave(); renderSections();
        });
      });
    }

    root.querySelector('[data-add-section]').addEventListener('click', function(){
      state.sections.push({ id: uid('sec'), name: 'Nová sekce', type: 'packages', color: '', items: [] });
      scheduleSave(); renderSections();
    });

    root.querySelector('[data-reset]').addEventListener('click', function(){
      if(confirm('Opravdu obnovit výchozí ceník? Projeví se až po kliknutí na "Uložit změny".')){
        state = JSON.parse(JSON.stringify(pmcAdminData.defaults));
        markDirty(); renderTiers(); renderSections();
      }
    });

    renderThemeGrid();
    renderLabelsGrid();
    applyLivePreview();
    renderTiers();
    renderSections();
  });
})();
