(function(){
  'use strict';

  function czk(n){
    n = Number(n) || 0;
    return n.toLocaleString('cs-CZ') + ' Kč';
  }

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function parseDesc(raw){
    if(!raw) return '';
    var esc = escapeHtml(raw);
    esc = esc.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    var lines = esc.split('\n');
    var html = '';
    var inList = false;
    lines.forEach(function(line){
      var trimmed = line.trim();
      if(/^-\s?/.test(trimmed)){
        if(!inList){ html += '<ul>'; inList = true; }
        html += '<li>' + trimmed.replace(/^-\s?/, '') + '</li>';
      } else {
        if(inList){ html += '</ul>'; inList = false; }
        if(trimmed) html += '<p>' + trimmed + '</p>';
      }
    });
    if(inList) html += '</ul>';
    return html;
  }

  function applicableTier(tiers, count){
    if(!tiers || !tiers.length) return null;
    var eligible = tiers.filter(function(t){ return count >= Number(t.minCount); });
    if(!eligible.length) return null;
    return eligible.reduce(function(best, t){
      return Number(t.minCount) > Number(best.minCount) ? t : best;
    });
  }

  function buildExtraFieldsHtml(formFields){
    return (formFields || []).filter(function(f){ return f.enabled; }).map(function(f){
      var reqMark = f.required ? ' *' : '';
      var inputHtml = f.type === 'textarea'
        ? '<textarea data-f-extra="' + f.id + '" rows="3"></textarea>'
        : '<input type="' + (f.type || 'text') + '" data-f-extra="' + f.id + '">';
      return '<label class="pmc-modal-field"><span>' + escapeHtml(f.label) + reqMark + '</span>' + inputHtml + '</label>';
    }).join('');
  }

  function initInstance(root, config, labels, formFields, inquiryUrl){
    var selection = {};
    var customState = {};
    var lastQuote = { lines: [], subtotal: 0, discountLabel: '', discountAmount: 0, total: 0 };

    config.sections.forEach(function(sec){
      if(sec.type === 'packages'){ selection[sec.id] = null; }
      else { customState[sec.id] = { enabled: false, price: sec.defaultPrice || 0 }; }
    });

    root.innerHTML =
      '<div class="pmc-app">' +
        '<div class="pmc-top">' +
          '<div><p class="pmc-eyebrow">' + escapeHtml(labels.headerEyebrow) + '</p><h1 class="pmc-h1">' + escapeHtml(labels.headerTitle) + '</h1></div>' +
        '</div>' +
        '<div class="pmc-config-grid">' +
          '<div class="pmc-config-sections"></div>' +
          '<div class="pmc-ticket collapsed">' +
            '<div class="pmc-ticket-head">' +
              '<p class="pmc-ticket-eyebrow">' + escapeHtml(labels.ticketEyebrow) + '</p>' +
              '<p class="pmc-ticket-title">' + escapeHtml(labels.ticketTitle) + '</p>' +
            '</div>' +
            '<div class="pmc-notch-row"><div class="pmc-notch-line"></div></div>' +
            '<div class="pmc-ticket-body"></div>' +
            '<div class="pmc-ticket-discount-wrap"></div>' +
            '<div class="pmc-ticket-total">' +
              '<span class="t-label">' + escapeHtml(labels.totalLabel) + '</span>' +
              '<button type="button" class="pmc-ticket-toggle" data-ticket-toggle aria-label="Zobrazit rozpis">▾</button>' +
              '<span class="t-value">0 Kč</span>' +
            '</div>' +
            '<div class="pmc-ticket-actions"><button type="button" class="pmc-btn-send" data-open-modal>' + escapeHtml(labels.sendButtonLabel) + '</button></div>' +
          '</div>' +
        '</div>' +
        '<div class="pmc-modal-overlay" hidden>' +
          '<div class="pmc-modal">' +
            '<h3>' + escapeHtml(labels.modalTitle) + '</h3>' +
            '<p class="pmc-modal-summary">' + escapeHtml(labels.modalTotalPrefix) + ' <strong class="pmc-modal-total">0 Kč</strong></p>' +
            '<label class="pmc-modal-field"><span>' + escapeHtml(labels.modalNameLabel) + '</span><input type="text" data-f-name></label>' +
            '<label class="pmc-modal-field"><span>' + escapeHtml(labels.modalEmailLabel) + '</span><input type="email" data-f-email></label>' +
            buildExtraFieldsHtml(formFields) +
            '<input type="text" class="pmc-modal-hp" data-f-hp tabindex="-1" autocomplete="off">' +
            '<div class="pmc-modal-actions">' +
              '<button type="button" class="pmc-btn pmc-btn-ghost" data-modal-cancel>' + escapeHtml(labels.modalCancelLabel) + '</button>' +
              '<button type="button" class="pmc-btn pmc-btn-gold" data-modal-send>' + escapeHtml(labels.modalSendLabel) + '</button>' +
            '</div>' +
            '<p class="pmc-modal-status"></p>' +
          '</div>' +
        '</div>' +
      '</div>';

    var sectionsWrap = root.querySelector('.pmc-config-sections');
    var ticketBody = root.querySelector('.pmc-ticket-body');
    var discountWrap = root.querySelector('.pmc-ticket-discount-wrap');
    var totalEl = root.querySelector('.pmc-ticket-total .t-value');
    var overlay = root.querySelector('.pmc-modal-overlay');
    var modalTotal = root.querySelector('.pmc-modal-total');
    var modalStatus = root.querySelector('.pmc-modal-status');
    var sendBtn = root.querySelector('[data-modal-send]');
    var openBtn = root.querySelector('[data-open-modal]');
    var ticketEl = root.querySelector('.pmc-ticket');
    var toggleBtn = root.querySelector('[data-ticket-toggle]');

    toggleBtn.addEventListener('click', function(){
      var collapsed = ticketEl.classList.toggle('collapsed');
      toggleBtn.classList.toggle('expanded', !collapsed);
      toggleBtn.textContent = collapsed ? '▾' : '▴';
    });

    (function initDesktopSticky(){
      var grid = root.querySelector('.pmc-config-grid');
      var topGap = 28;
      var cachedLeft = null, cachedWidth = null;
      var raf = null;

      function clearFixed(){
        ticketEl.style.position = '';
        ticketEl.style.top = '';
        ticketEl.style.left = '';
        ticketEl.style.width = '';
      }

      function measureNatural(){
        if(ticketEl.style.position === 'fixed' || ticketEl.style.position === 'absolute') return;
        var r = ticketEl.getBoundingClientRect();
        cachedLeft = r.left;
        cachedWidth = r.width;
      }

      function update(){
        raf = null;
        if(window.innerWidth <= 880){
          clearFixed();
          return;
        }
        measureNatural();
        if(cachedLeft === null) return;

        var gridRect = grid.getBoundingClientRect();
        var scrollY = window.scrollY || window.pageYOffset;
        var gridTopAbs = gridRect.top + scrollY;
        var gridBottomAbs = gridRect.bottom + scrollY;
        var ticketHeight = ticketEl.offsetHeight;

        if(scrollY + topGap <= gridTopAbs){
          clearFixed();
        } else if(scrollY + topGap + ticketHeight >= gridBottomAbs){
          if(getComputedStyle(grid).position === 'static'){ grid.style.position = 'relative'; }
          ticketEl.style.position = 'absolute';
          ticketEl.style.top = Math.max(0, gridRect.height - ticketHeight) + 'px';
          ticketEl.style.left = (cachedLeft - gridRect.left) + 'px';
          ticketEl.style.width = cachedWidth + 'px';
        } else {
          ticketEl.style.position = 'fixed';
          ticketEl.style.top = topGap + 'px';
          ticketEl.style.left = cachedLeft + 'px';
          ticketEl.style.width = cachedWidth + 'px';
        }
      }

      function requestUpdate(){
        if(!raf) raf = requestAnimationFrame(update);
      }

      window.addEventListener('scroll', requestUpdate, { passive: true });
      window.addEventListener('resize', function(){ cachedLeft = null; requestUpdate(); });
      requestUpdate();
    })();

    function buildOption(sec, itemId, name, price, desc){
      var isNone = itemId === null;
      var checked = selection[sec.id] === itemId;
      var opt = document.createElement('label');
      opt.className = 'pmc-option' + (checked ? ' selected' : '');
      opt.innerHTML =
        '<span class="pmc-option-left">' +
          '<input type="radio" name="' + sec.id + '" value="' + (isNone ? '__none__' : itemId) + '" ' + (checked ? 'checked' : '') + '>' +
          '<span class="pmc-option-text">' +
            '<span class="pmc-option-name">' + escapeHtml(name) + '</span>' +
            (desc ? '<div class="pmc-option-desc">' + parseDesc(desc) + '</div>' : '') +
          '</span>' +
        '</span>' +
        '<span class="pmc-option-price">' + (isNone ? '' : czk(price)) + '</span>';
      return opt;
    }

    function renderSections(){
      sectionsWrap.innerHTML = '';
      config.sections.forEach(function(sec){
        var card = document.createElement('div');
        card.className = 'pmc-section-card';
        if(sec.color){ card.style.setProperty('--pmc-section-accent', sec.color); }

        var head = document.createElement('div');
        head.className = 'pmc-section-head';
        head.innerHTML = '<span class="pmc-section-title">' + escapeHtml(sec.name) + '</span>' +
          '<span class="pmc-section-hint">' + escapeHtml(sec.type === 'packages' ? labels.packagesHint : labels.customHint) + '</span>';
        card.appendChild(head);

        if(sec.type === 'packages'){
          card.appendChild(buildOption(sec, null, labels.noneOptionLabel, null, ''));
          (sec.items || []).forEach(function(it){
            card.appendChild(buildOption(sec, it.id, it.name, it.price, it.desc));
          });
        } else {
          if(sec.desc){
            var d = document.createElement('div');
            d.className = 'pmc-custom-desc';
            d.innerHTML = parseDesc(sec.desc);
            card.appendChild(d);
          }
          var cs = customState[sec.id];
          var row = document.createElement('div');
          row.className = 'pmc-custom-row';
          row.innerHTML =
            '<label><input type="checkbox" ' + (cs.enabled ? 'checked' : '') + ' data-cx="' + sec.id + '"> ' + escapeHtml(labels.includePrefix) + ' ' + escapeHtml(sec.name.toLowerCase()) + '</label>' +
            '<input type="number" min="0" step="100" value="' + cs.price + '" data-cxp="' + sec.id + '" ' + (cs.enabled ? '' : 'disabled') + '>' +
            '<span class="pmc-unit">' + escapeHtml(labels.unitLabel) + '</span>';
          card.appendChild(row);
        }
        sectionsWrap.appendChild(card);
      });

      sectionsWrap.querySelectorAll('input[type=radio]').forEach(function(r){
        r.addEventListener('change', function(e){
          var secId = e.target.name;
          selection[secId] = e.target.value === '__none__' ? null : e.target.value;
          renderSections();
          renderTicket();
        });
      });
      sectionsWrap.querySelectorAll('input[data-cx]').forEach(function(cb){
        cb.addEventListener('change', function(e){
          customState[e.target.dataset.cx].enabled = e.target.checked;
          renderSections();
          renderTicket();
        });
      });
      sectionsWrap.querySelectorAll('input[data-cxp]').forEach(function(inp){
        inp.addEventListener('input', function(e){
          customState[e.target.dataset.cxp].price = Number(e.target.value) || 0;
          renderTicket();
        });
      });
    }

    function renderTicket(){
      ticketBody.innerHTML = '';
      var total = 0;
      var lines = [];

      config.sections.forEach(function(sec){
        if(sec.type === 'packages'){
          var selId = selection[sec.id];
          if(selId){
            var item = (sec.items || []).filter(function(i){ return i.id === selId; })[0];
            if(item){ lines.push({ cat: sec.name, name: item.name, price: item.price }); total += Number(item.price) || 0; }
          }
        } else {
          var cs = customState[sec.id];
          if(cs.enabled){ lines.push({ cat: sec.name, name: sec.name, price: cs.price }); total += Number(cs.price) || 0; }
        }
      });

      if(!lines.length){
        ticketBody.innerHTML = '<p class="pmc-ticket-empty">' + escapeHtml(labels.emptyText) + '</p>';
      } else {
        lines.forEach(function(l){
          var row = document.createElement('div');
          row.className = 'pmc-ticket-line';
          row.innerHTML = '<span class="l-name">' + escapeHtml(l.name) + '<span class="l-cat">' + escapeHtml(l.cat) + '</span></span><span class="l-price">' + czk(l.price) + '</span>';
          ticketBody.appendChild(row);
        });
      }

      discountWrap.innerHTML = '';
      var tier = applicableTier(config.discountTiers, lines.length);
      var finalTotal = total;
      var discountAmount = 0;
      var discountTag = '';

      if(lines.length && tier){
        discountAmount = tier.type === 'percent' ? Math.round(total * tier.value / 100) : Number(tier.value) || 0;
        finalTotal = Math.max(0, total - discountAmount);
        discountTag = tier.minCount + '+ služby, ' + (tier.type === 'percent' ? (tier.value + '%') : czk(tier.value));

        var sub = document.createElement('div');
        sub.className = 'pmc-ticket-subtotal';
        sub.innerHTML = '<span>' + escapeHtml(labels.subtotalLabel) + '</span><span>' + czk(total) + '</span>';
        discountWrap.appendChild(sub);

        var disc = document.createElement('div');
        disc.className = 'pmc-ticket-discount';
        disc.innerHTML = '<span>' + escapeHtml(labels.discountLabel) + ' <span class="d-tag">(' + escapeHtml(discountTag) + ')</span></span><span>−' + czk(discountAmount) + '</span>';
        discountWrap.appendChild(disc);
      }

      totalEl.textContent = czk(finalTotal);
      lastQuote = { lines: lines, subtotal: total, discountLabel: discountTag, discountAmount: discountAmount, total: finalTotal };
      openBtn.disabled = !lines.length;
      openBtn.title = lines.length ? '' : labels.noSelectionTitle;
    }

    function openModal(){
      if(!lastQuote.lines.length){
        return;
      }
      modalTotal.textContent = czk(lastQuote.total);
      modalStatus.textContent = '';
      modalStatus.className = 'pmc-modal-status';
      overlay.hidden = false;
    }
    function closeModal(){ overlay.hidden = true; }

    root.querySelector('[data-open-modal]').addEventListener('click', openModal);
    root.querySelector('[data-modal-cancel]').addEventListener('click', closeModal);
    overlay.addEventListener('click', function(e){ if(e.target === overlay) closeModal(); });

    sendBtn.addEventListener('click', function(){
      var name = root.querySelector('[data-f-name]').value.trim();
      var email = root.querySelector('[data-f-email]').value.trim();
      var hp = root.querySelector('[data-f-hp]').value;

      var extra = {};
      var missingRequired = false;
      (formFields || []).filter(function(f){ return f.enabled; }).forEach(function(f){
        var el = root.querySelector('[data-f-extra="' + f.id + '"]');
        var val = el ? el.value.trim() : '';
        extra[f.id] = val;
        if(f.required && !val) missingRequired = true;
      });

      if(!name || !email || email.indexOf('@') === -1 || missingRequired){
        modalStatus.textContent = labels.modalValidationError;
        modalStatus.className = 'pmc-modal-status error';
        return;
      }
      if(!inquiryUrl){
        modalStatus.textContent = labels.modalGenericError;
        modalStatus.className = 'pmc-modal-status error';
        return;
      }

      sendBtn.disabled = true;
      modalStatus.textContent = labels.modalSendingText;
      modalStatus.className = 'pmc-modal-status';

      fetch(inquiryUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name, email: email, extra: extra, website: hp,
          lines: lastQuote.lines, subtotal: lastQuote.subtotal,
          discountLabel: lastQuote.discountLabel, discountAmount: lastQuote.discountAmount,
          total: lastQuote.total
        })
      }).then(function(res){ return res.json().then(function(data){ return { ok: res.ok, data: data }; }); })
        .then(function(r){
          if(!r.ok){ throw new Error((r.data && r.data.message) || labels.modalGenericError); }
          modalStatus.textContent = labels.modalSuccessText;
          modalStatus.className = 'pmc-modal-status ok';
          setTimeout(closeModal, 2200);
        })
        .catch(function(err){
          modalStatus.textContent = err.message || labels.modalGenericError;
          modalStatus.className = 'pmc-modal-status error';
        })
        .finally(function(){ sendBtn.disabled = false; });
    });

    renderSections();
    renderTicket();
  }

  document.addEventListener('DOMContentLoaded', function(){
    if(typeof pmcPublicData === 'undefined' || !pmcPublicData.config) return;
    document.querySelectorAll('.pmc-public-instance').forEach(function(root){
      initInstance(root, pmcPublicData.config, pmcPublicData.labels || {}, pmcPublicData.formFields || [], pmcPublicData.inquiryUrl);
    });
  });
})();
