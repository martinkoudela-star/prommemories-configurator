(function(){
  'use strict';

  var THEME_KEY = 'pmc-theme-pref';

  function czk(n){
    n = Number(n) || 0;
    return n.toLocaleString('cs-CZ') + ' Kč';
  }

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function applicableTier(tiers, count){
    if(!tiers || !tiers.length) return null;
    var eligible = tiers.filter(function(t){ return count >= Number(t.minCount); });
    if(!eligible.length) return null;
    return eligible.reduce(function(best, t){
      return Number(t.minCount) > Number(best.minCount) ? t : best;
    });
  }

  function initInstance(root, config){
    var selection = {};
    var customState = {};

    config.sections.forEach(function(sec){
      if(sec.type === 'packages'){ selection[sec.id] = null; }
      else { customState[sec.id] = { enabled: false, price: sec.defaultPrice || 0 }; }
    });

    root.innerHTML =
      '<div class="pmc-app">' +
        '<div class="pmc-top">' +
          '<div><p class="pmc-eyebrow">PromMemories.cz · Maturitní plesy</p><h1 class="pmc-h1">Konfigurátor cen</h1></div>' +
          '<div class="pmc-theme-toggle">' +
            '<button type="button" class="pmc-theme-btn" data-theme-btn="day" title="Denní režim" aria-label="Denní režim">' +
              '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="4.5"/><path d="M12 2.5v2.5M12 19v2.5M4.2 4.2l1.8 1.8M18 18l1.8 1.8M2.5 12H5M19 12h2.5M4.2 19.8L6 18M18 6l1.8-1.8"/></svg>' +
            '</button>' +
            '<button type="button" class="pmc-theme-btn" data-theme-btn="night" title="Noční režim" aria-label="Noční režim">' +
              '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M20.4 14.7A8.5 8.5 0 0 1 9.3 3.6a.6.6 0 0 0-.7-.8A9.5 9.5 0 1 0 21.2 15.4a.6.6 0 0 0-.8-.7Z"/></svg>' +
            '</button>' +
          '</div>' +
        '</div>' +
        '<div class="pmc-config-grid">' +
          '<div class="pmc-config-sections"></div>' +
          '<div class="pmc-ticket">' +
            '<div class="pmc-ticket-head">' +
              '<p class="pmc-ticket-eyebrow">Cenová nabídka</p>' +
              '<p class="pmc-ticket-title">Rozpis vybraných služeb</p>' +
            '</div>' +
            '<div class="pmc-notch-row"><div class="pmc-notch-line"></div></div>' +
            '<div class="pmc-ticket-body"></div>' +
            '<div class="pmc-ticket-discount-wrap"></div>' +
            '<div class="pmc-ticket-total"><span class="t-label">Celkem</span><span class="t-value">0 Kč</span></div>' +
            '<div class="pmc-ticket-actions"><button type="button" class="pmc-btn-print">Tisk / export nabídky</button></div>' +
          '</div>' +
        '</div>' +
      '</div>';

    var sectionsWrap = root.querySelector('.pmc-config-sections');
    var ticketBody = root.querySelector('.pmc-ticket-body');
    var discountWrap = root.querySelector('.pmc-ticket-discount-wrap');
    var totalEl = root.querySelector('.pmc-ticket-total .t-value');

    function buildOption(sec, itemId, name, price, desc){
      var isNone = itemId === null;
      var checked = selection[sec.id] === itemId;
      var opt = document.createElement('label');
      opt.className = 'pmc-option' + (checked ? ' selected' : '');
      opt.innerHTML =
        '<span class="pmc-option-left">' +
          '<input type="radio" name="' + sec.id + '" value="' + (isNone ? '__none__' : itemId) + '" ' + (checked ? 'checked' : '') + '>' +
          '<span class="pmc-option-text">' +
            '<span class="pmc-option-name">' + escapeHtml(name) + '</span>' +
            (desc ? '<span class="pmc-option-desc">' + escapeHtml(desc) + '</span>' : '') +
          '</span>' +
        '</span>' +
        '<span class="pmc-option-price">' + (isNone ? '' : czk(price)) + '</span>';
      return opt;
    }

    function renderSections(){
      sectionsWrap.innerHTML = '';
      config.sections.forEach(function(sec){
        var card = document.createElement('div');
        card.className = 'pmc-section-card';
        var head = document.createElement('div');
        head.className = 'pmc-section-head';
        head.innerHTML = '<span class="pmc-section-title">' + escapeHtml(sec.name) + '</span>' +
          '<span class="pmc-section-hint">' + (sec.type === 'packages' ? 'vyber jednu variantu, nebo přeskoč' : 'individuální cena') + '</span>';
        card.appendChild(head);

        if(sec.type === 'packages'){
          card.appendChild(buildOption(sec, null, 'Nevybráno', null, ''));
          (sec.items || []).forEach(function(it){
            card.appendChild(buildOption(sec, it.id, it.name, it.price, it.desc));
          });
        } else {
          if(sec.desc){
            var d = document.createElement('p');
            d.className = 'pmc-custom-desc';
            d.textContent = sec.desc;
            card.appendChild(d);
          }
          var cs = customState[sec.id];
          var row = document.createElement('div');
          row.className = 'pmc-custom-row';
          row.innerHTML =
            '<label><input type="checkbox" ' + (cs.enabled ? 'checked' : '') + ' data-cx="' + sec.id + '"> Zahrnout ' + escapeHtml(sec.name.toLowerCase()) + '</label>' +
            '<input type="number" min="0" step="100" value="' + cs.price + '" data-cxp="' + sec.id + '" ' + (cs.enabled ? '' : 'disabled') + '>' +
            '<span class="pmc-unit">Kč</span>';
          card.appendChild(row);
        }
        sectionsWrap.appendChild(card);
      });

      sectionsWrap.querySelectorAll('input[type=radio]').forEach(function(r){
        r.addEventListener('change', function(e){
          var secId = e.target.name;
          selection[secId] = e.target.value === '__none__' ? null : e.target.value;
          renderSections();
          renderTicket();
        });
      });
      sectionsWrap.querySelectorAll('input[data-cx]').forEach(function(cb){
        cb.addEventListener('change', function(e){
          customState[e.target.dataset.cx].enabled = e.target.checked;
          renderSections();
          renderTicket();
        });
      });
      sectionsWrap.querySelectorAll('input[data-cxp]').forEach(function(inp){
        inp.addEventListener('input', function(e){
          customState[e.target.dataset.cxp].price = Number(e.target.value) || 0;
          renderTicket();
        });
      });
    }

    function renderTicket(){
      ticketBody.innerHTML = '';
      var total = 0;
      var lines = [];

      config.sections.forEach(function(sec){
        if(sec.type === 'packages'){
          var selId = selection[sec.id];
          if(selId){
            var item = (sec.items || []).filter(function(i){ return i.id === selId; })[0];
            if(item){ lines.push({ cat: sec.name, name: item.name, price: item.price }); total += Number(item.price) || 0; }
          }
        } else {
          var cs = customState[sec.id];
          if(cs.enabled){ lines.push({ cat: sec.name, name: sec.name, price: cs.price }); total += Number(cs.price) || 0; }
        }
      });

      if(!lines.length){
        ticketBody.innerHTML = '<p class="pmc-ticket-empty">Zatím nic nevybráno.</p>';
      } else {
        lines.forEach(function(l){
          var row = document.createElement('div');
          row.className = 'pmc-ticket-line';
          row.innerHTML = '<span class="l-name">' + escapeHtml(l.name) + '<span class="l-cat">' + escapeHtml(l.cat) + '</span></span><span class="l-price">' + czk(l.price) + '</span>';
          ticketBody.appendChild(row);
        });
      }

      discountWrap.innerHTML = '';
      var tier = applicableTier(config.discountTiers, lines.length);
      var finalTotal = total;

      if(lines.length && tier){
        var discountAmount = tier.type === 'percent' ? Math.round(total * tier.value / 100) : Number(tier.value) || 0;
        finalTotal = Math.max(0, total - discountAmount);

        var sub = document.createElement('div');
        sub.className = 'pmc-ticket-subtotal';
        sub.innerHTML = '<span>Mezisoučet</span><span>' + czk(total) + '</span>';
        discountWrap.appendChild(sub);

        var disc = document.createElement('div');
        disc.className = 'pmc-ticket-discount';
        var tag = tier.type === 'percent' ? (tier.value + '%') : czk(tier.value);
        disc.innerHTML = '<span>Množstevní sleva <span class="d-tag">(' + tier.minCount + '+ služby, ' + tag + ')</span></span><span>−' + czk(discountAmount) + '</span>';
        discountWrap.appendChild(disc);
      }

      totalEl.textContent = czk(finalTotal);
    }

    root.querySelector('.pmc-btn-print').addEventListener('click', function(){ window.print(); });

    function applyTheme(theme){
      root.setAttribute('data-theme', theme);
      root.querySelectorAll('[data-theme-btn]').forEach(function(btn){
        btn.classList.toggle('active', btn.dataset.themeBtn === theme);
      });
    }
    function setTheme(theme){
      applyTheme(theme);
      try{ localStorage.setItem(THEME_KEY, theme); }catch(e){}
    }
    var savedTheme = null;
    try{ savedTheme = localStorage.getItem(THEME_KEY); }catch(e){}
    if(!savedTheme){
      savedTheme = (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches) ? 'day' : 'night';
    }
    applyTheme(savedTheme);
    root.querySelectorAll('[data-theme-btn]').forEach(function(btn){
      btn.addEventListener('click', function(){ setTheme(btn.dataset.themeBtn); });
    });

    renderSections();
    renderTicket();
  }

  document.addEventListener('DOMContentLoaded', function(){
    if(typeof pmcPublicData === 'undefined' || !pmcPublicData.config) return;
    document.querySelectorAll('.pmc-public-instance').forEach(function(root){
      initInstance(root, pmcPublicData.config);
    });
  });
})();
