(function(){
  'use strict';

  function czk(n){
    n = Number(n) || 0;
    return n.toLocaleString('cs-CZ') + ' Kč';
  }

  function escapeHtml(s){
    return String(s).replace(/[&<>"']/g, function(c){
      return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c];
    });
  }

  function applicableTier(tiers, count){
    if(!tiers || !tiers.length) return null;
    var eligible = tiers.filter(function(t){ return count >= Number(t.minCount); });
    if(!eligible.length) return null;
    return eligible.reduce(function(best, t){
      return Number(t.minCount) > Number(best.minCount) ? t : best;
    });
  }

  function initInstance(root, config, inquiryUrl){
    var selection = {};
    var customState = {};
    var lastQuote = { lines: [], subtotal: 0, discountLabel: '', discountAmount: 0, total: 0 };

    config.sections.forEach(function(sec){
      if(sec.type === 'packages'){ selection[sec.id] = null; }
      else { customState[sec.id] = { enabled: false, price: sec.defaultPrice || 0 }; }
    });

    root.innerHTML =
      '<div class="pmc-app">' +
        '<div class="pmc-top">' +
          '<div><p class="pmc-eyebrow">PromMemories.cz · Maturitní plesy</p><h1 class="pmc-h1">Konfigurátor cen</h1></div>' +
        '</div>' +
        '<div class="pmc-config-grid">' +
          '<div class="pmc-config-sections"></div>' +
          '<div class="pmc-ticket collapsed">' +
            '<div class="pmc-ticket-head">' +
              '<p class="pmc-ticket-eyebrow">Cenová nabídka</p>' +
              '<p class="pmc-ticket-title">Rozpis vybraných služeb</p>' +
            '</div>' +
            '<div class="pmc-notch-row"><div class="pmc-notch-line"></div></div>' +
            '<div class="pmc-ticket-body"></div>' +
            '<div class="pmc-ticket-discount-wrap"></div>' +
            '<div class="pmc-ticket-total">' +
              '<span class="t-label">Celkem</span>' +
              '<button type="button" class="pmc-ticket-toggle" data-ticket-toggle aria-label="Zobrazit rozpis">▾</button>' +
              '<span class="t-value">0 Kč</span>' +
            '</div>' +
            '<div class="pmc-ticket-actions"><button type="button" class="pmc-btn-send" data-open-modal>Odeslat poptávku</button></div>' +
          '</div>' +
        '</div>' +
        '<div class="pmc-modal-overlay" hidden>' +
          '<div class="pmc-modal">' +
            '<h3>Odeslat poptávku</h3>' +
            '<p class="pmc-modal-summary">Celková cena: <strong class="pmc-modal-total">0 Kč</strong></p>' +
            '<label class="pmc-modal-field"><span>Jméno a příjmení</span><input type="text" data-f-name></label>' +
            '<label class="pmc-modal-field"><span>E-mail</span><input type="email" data-f-email></label>' +
            '<label class="pmc-modal-field"><span>Telefon</span><input type="tel" data-f-phone></label>' +
            '<input type="text" class="pmc-modal-hp" data-f-hp tabindex="-1" autocomplete="off">' +
            '<div class="pmc-modal-actions">' +
              '<button type="button" class="pmc-btn pmc-btn-ghost" data-modal-cancel>Zrušit</button>' +
              '<button type="button" class="pmc-btn pmc-btn-gold" data-modal-send>Odeslat</button>' +
            '</div>' +
            '<p class="pmc-modal-status"></p>' +
          '</div>' +
        '</div>' +
      '</div>';

    var sectionsWrap = root.querySelector('.pmc-config-sections');
    var ticketBody = root.querySelector('.pmc-ticket-body');
    var discountWrap = root.querySelector('.pmc-ticket-discount-wrap');
    var totalEl = root.querySelector('.pmc-ticket-total .t-value');
    var overlay = root.querySelector('.pmc-modal-overlay');
    var modalTotal = root.querySelector('.pmc-modal-total');
    var modalStatus = root.querySelector('.pmc-modal-status');
    var sendBtn = root.querySelector('[data-modal-send]');
    var openBtn = root.querySelector('[data-open-modal]');
    var ticketEl = root.querySelector('.pmc-ticket');
    var toggleBtn = root.querySelector('[data-ticket-toggle]');

    toggleBtn.addEventListener('click', function(){
      var collapsed = ticketEl.classList.toggle('collapsed');
      toggleBtn.classList.toggle('expanded', !collapsed);
      toggleBtn.textContent = collapsed ? '▾' : '▴';
    });

    function buildOption(sec, itemId, name, price, desc){
      var isNone = itemId === null;
      var checked = selection[sec.id] === itemId;
      var opt = document.createElement('label');
      opt.className = 'pmc-option' + (checked ? ' selected' : '');
      opt.innerHTML =
        '<span class="pmc-option-left">' +
          '<input type="radio" name="' + sec.id + '" value="' + (isNone ? '__none__' : itemId) + '" ' + (checked ? 'checked' : '') + '>' +
          '<span class="pmc-option-text">' +
            '<span class="pmc-option-name">' + escapeHtml(name) + '</span>' +
            (desc ? '<span class="pmc-option-desc">' + escapeHtml(desc) + '</span>' : '') +
          '</span>' +
        '</span>' +
        '<span class="pmc-option-price">' + (isNone ? '' : czk(price)) + '</span>';
      return opt;
    }

    function renderSections(){
      sectionsWrap.innerHTML = '';
      config.sections.forEach(function(sec){
        var card = document.createElement('div');
        card.className = 'pmc-section-card';
        if(sec.color){ card.style.setProperty('--pmc-section-accent', sec.color); }

        var head = document.createElement('div');
        head.className = 'pmc-section-head';
        head.innerHTML = '<span class="pmc-section-title">' + escapeHtml(sec.name) + '</span>' +
          '<span class="pmc-section-hint">' + (sec.type === 'packages' ? 'vyber jednu variantu, nebo přeskoč' : 'individuální cena') + '</span>';
        card.appendChild(head);

        if(sec.type === 'packages'){
          card.appendChild(buildOption(sec, null, 'Nevybráno', null, ''));
          (sec.items || []).forEach(function(it){
            card.appendChild(buildOption(sec, it.id, it.name, it.price, it.desc));
          });
        } else {
          if(sec.desc){
            var d = document.createElement('p');
            d.className = 'pmc-custom-desc';
            d.textContent = sec.desc;
            card.appendChild(d);
          }
          var cs = customState[sec.id];
          var row = document.createElement('div');
          row.className = 'pmc-custom-row';
          row.innerHTML =
            '<label><input type="checkbox" ' + (cs.enabled ? 'checked' : '') + ' data-cx="' + sec.id + '"> Zahrnout ' + escapeHtml(sec.name.toLowerCase()) + '</label>' +
            '<input type="number" min="0" step="100" value="' + cs.price + '" data-cxp="' + sec.id + '" ' + (cs.enabled ? '' : 'disabled') + '>' +
            '<span class="pmc-unit">Kč</span>';
          card.appendChild(row);
        }
        sectionsWrap.appendChild(card);
      });

      sectionsWrap.querySelectorAll('input[type=radio]').forEach(function(r){
        r.addEventListener('change', function(e){
          var secId = e.target.name;
          selection[secId] = e.target.value === '__none__' ? null : e.target.value;
          renderSections();
          renderTicket();
        });
      });
      sectionsWrap.querySelectorAll('input[data-cx]').forEach(function(cb){
        cb.addEventListener('change', function(e){
          customState[e.target.dataset.cx].enabled = e.target.checked;
          renderSections();
          renderTicket();
        });
      });
      sectionsWrap.querySelectorAll('input[data-cxp]').forEach(function(inp){
        inp.addEventListener('input', function(e){
          customState[e.target.dataset.cxp].price = Number(e.target.value) || 0;
          renderTicket();
        });
      });
    }

    function renderTicket(){
      ticketBody.innerHTML = '';
      var total = 0;
      var lines = [];

      config.sections.forEach(function(sec){
        if(sec.type === 'packages'){
          var selId = selection[sec.id];
          if(selId){
            var item = (sec.items || []).filter(function(i){ return i.id === selId; })[0];
            if(item){ lines.push({ cat: sec.name, name: item.name, price: item.price }); total += Number(item.price) || 0; }
          }
        } else {
          var cs = customState[sec.id];
          if(cs.enabled){ lines.push({ cat: sec.name, name: sec.name, price: cs.price }); total += Number(cs.price) || 0; }
        }
      });

      if(!lines.length){
        ticketBody.innerHTML = '<p class="pmc-ticket-empty">Zatím nic nevybráno.</p>';
      } else {
        lines.forEach(function(l){
          var row = document.createElement('div');
          row.className = 'pmc-ticket-line';
          row.innerHTML = '<span class="l-name">' + escapeHtml(l.name) + '<span class="l-cat">' + escapeHtml(l.cat) + '</span></span><span class="l-price">' + czk(l.price) + '</span>';
          ticketBody.appendChild(row);
        });
      }

      discountWrap.innerHTML = '';
      var tier = applicableTier(config.discountTiers, lines.length);
      var finalTotal = total;
      var discountAmount = 0;
      var discountLabel = '';

      if(lines.length && tier){
        discountAmount = tier.type === 'percent' ? Math.round(total * tier.value / 100) : Number(tier.value) || 0;
        finalTotal = Math.max(0, total - discountAmount);
        discountLabel = tier.minCount + '+ služby, ' + (tier.type === 'percent' ? (tier.value + '%') : czk(tier.value));

        var sub = document.createElement('div');
        sub.className = 'pmc-ticket-subtotal';
        sub.innerHTML = '<span>Mezisoučet</span><span>' + czk(total) + '</span>';
        discountWrap.appendChild(sub);

        var disc = document.createElement('div');
        disc.className = 'pmc-ticket-discount';
        disc.innerHTML = '<span>Množstevní sleva <span class="d-tag">(' + escapeHtml(discountLabel) + ')</span></span><span>−' + czk(discountAmount) + '</span>';
        discountWrap.appendChild(disc);
      }

      totalEl.textContent = czk(finalTotal);
      lastQuote = { lines: lines, subtotal: total, discountLabel: discountLabel, discountAmount: discountAmount, total: finalTotal };
      openBtn.disabled = !lines.length;
      openBtn.title = lines.length ? '' : 'Nejdřív vyber alespoň jednu službu';
    }

    function openModal(){
      if(!lastQuote.lines.length){
        return;
      }
      modalTotal.textContent = czk(lastQuote.total);
      modalStatus.textContent = '';
      modalStatus.className = 'pmc-modal-status';
      overlay.hidden = false;
    }
    function closeModal(){ overlay.hidden = true; }

    root.querySelector('[data-open-modal]').addEventListener('click', openModal);
    root.querySelector('[data-modal-cancel]').addEventListener('click', closeModal);
    overlay.addEventListener('click', function(e){ if(e.target === overlay) closeModal(); });

    sendBtn.addEventListener('click', function(){
      var name = root.querySelector('[data-f-name]').value.trim();
      var email = root.querySelector('[data-f-email]').value.trim();
      var phone = root.querySelector('[data-f-phone]').value.trim();
      var hp = root.querySelector('[data-f-hp]').value;

      if(!name || !email || email.indexOf('@') === -1){
        modalStatus.textContent = 'Vyplň prosím jméno a platný e-mail.';
        modalStatus.className = 'pmc-modal-status error';
        return;
      }
      if(!inquiryUrl){
        modalStatus.textContent = 'Poptávku se nepodařilo odeslat (chybí konfigurace).';
        modalStatus.className = 'pmc-modal-status error';
        return;
      }

      sendBtn.disabled = true;
      modalStatus.textContent = 'Odesílám…';
      modalStatus.className = 'pmc-modal-status';

      fetch(inquiryUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: name, email: email, phone: phone, website: hp,
          lines: lastQuote.lines, subtotal: lastQuote.subtotal,
          discountLabel: lastQuote.discountLabel, discountAmount: lastQuote.discountAmount,
          total: lastQuote.total
        })
      }).then(function(res){ return res.json().then(function(data){ return { ok: res.ok, data: data }; }); })
        .then(function(r){
          if(!r.ok){ throw new Error((r.data && r.data.message) || 'Odeslání selhalo.'); }
          modalStatus.textContent = 'Poptávka byla odeslána, ozveme se ti co nejdřív.';
          modalStatus.className = 'pmc-modal-status ok';
          setTimeout(closeModal, 2200);
        })
        .catch(function(err){
          modalStatus.textContent = err.message || 'Odeslání selhalo, zkus to prosím znovu.';
          modalStatus.className = 'pmc-modal-status error';
        })
        .finally(function(){ sendBtn.disabled = false; });
    });

    renderSections();
    renderTicket();
  }

  document.addEventListener('DOMContentLoaded', function(){
    if(typeof pmcPublicData === 'undefined' || !pmcPublicData.config) return;
    document.querySelectorAll('.pmc-public-instance').forEach(function(root){
      initInstance(root, pmcPublicData.config, pmcPublicData.inquiryUrl);
    });
  });
})();
