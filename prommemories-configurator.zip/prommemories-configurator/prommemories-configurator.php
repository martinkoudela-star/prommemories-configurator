<?php
/**
 * Plugin Name: PromMemories Konfigurátor cen
 * Description: Konfigurátor cen služeb na maturitní plesy (fotobudka, fotograf, kameraman, videobudka, výzdoba) s množstevními slevami. Administrace ceníku + shortcode [prommemories_configurator] pro vložení na stránku.
 * Version: 1.0.0
 * Author: LONGTERMLAPSE s.r.o.
 * Text Domain: prommemories-configurator
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'PMC_VERSION', '1.0.0' );
define( 'PMC_OPTION_KEY', 'pmc_pricing_config' );
define( 'PMC_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'PMC_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

// URL to the update manifest (JSON) — see update.json.example for the format.
// Point this at your GitHub repo, e.g.:
// https://raw.githubusercontent.com/USERNAME/REPO/main/update.json
define( 'PMC_UPDATE_MANIFEST_URL', 'https://raw.githubusercontent.com/martinkoudela-star/prommemories-configurator/main/update.json' );

/* ------------------------------------------------------------------ */
/*  Default pricing data (used on first activation / "reset" button)   */
/* ------------------------------------------------------------------ */

function pmc_default_config() {
	return array(
		'sections' => array(
			array(
				'id'    => 'fotobudka',
				'name'  => 'Fotobudka',
				'type'  => 'packages',
				'items' => array(
					array( 'id' => 'fb-v1', 'name' => 'Fotobudka v1', 'price' => 0,    'desc' => '', 'breakdown' => array() ),
					array( 'id' => 'fb-v2', 'name' => 'Fotobudka v2', 'price' => 0,    'desc' => '', 'breakdown' => array() ),
					array( 'id' => 'fb-v3', 'name' => 'Fotobudka v3', 'price' => 5000, 'desc' => '', 'breakdown' => array() ),
					array( 'id' => 'fb-v4', 'name' => 'Fotobudka v4', 'price' => 5000, 'desc' => '', 'breakdown' => array() ),
				),
			),
			array(
				'id'    => 'fotograf',
				'name'  => 'Fotograf',
				'type'  => 'packages',
				'items' => array(
					array(
						'id' => 'fg-1x', 'name' => 'Fotograf 1x', 'price' => 10000,
						'desc' => 'Fotografování celý večer, 400–600 fotografií, dodání do 3 týdnů, doprava po Čechách zdarma.',
						'breakdown' => array(),
					),
					array(
						'id' => 'fg-2x', 'name' => 'Fotograf 2x', 'price' => 19000,
						'desc' => 'Fotografování celý večer 2 fotografy, 400–600 fotografií na fotografa, dodání do 3 týdnů, doprava po Čechách zdarma.',
						'breakdown' => array(),
					),
				),
			),
			array(
				'id'    => 'kameraman',
				'name'  => 'Kameraman',
				'type'  => 'packages',
				'items' => array(
					array(
						'id' => 'km-1k', 'name' => 'Kameraman 1x krátká verze', 'price' => 13000,
						'desc' => 'Natáčení 1 kameramanem, krátká verze videa (3–5 min), dodání do 3 týdnů, doprava po Čechách zdarma.',
						'breakdown' => array(
							array( 'label' => 'Kameraman', 'amount' => 8000 ),
							array( 'label' => 'Postprodukce', 'amount' => 5000 ),
						),
					),
					array(
						'id' => 'km-2k', 'name' => 'Kameraman 2x krátká verze', 'price' => 20000,
						'desc' => 'Natáčení 2 kameramany, krátká verze videa (3–5 min), dodání do 3 týdnů, doprava po Čechách zdarma.',
						'breakdown' => array(
							array( 'label' => 'Kameraman 1', 'amount' => 7000 ),
							array( 'label' => 'Kameraman 2', 'amount' => 7000 ),
							array( 'label' => 'Postprodukce', 'amount' => 6000 ),
						),
					),
					array(
						'id' => 'km-2d', 'name' => 'Kameraman 2x dlouhá verze', 'price' => 26000,
						'desc' => 'Natáčení 2 kameramany, krátká i dlouhá verze videa (40–60 min), dodání do 3 týdnů, doprava po Čechách zdarma.',
						'breakdown' => array(
							array( 'label' => 'Kameraman 1', 'amount' => 8000 ),
							array( 'label' => 'Kameraman 2', 'amount' => 8000 ),
							array( 'label' => 'Postprodukce', 'amount' => 10000 ),
						),
					),
				),
			),
			array(
				'id'    => 'videobudka',
				'name'  => 'Videobudka',
				'type'  => 'packages',
				'items' => array(
					array(
						'id' => 'vb-2h', 'name' => 'Videobudka na 2h', 'price' => 9610,
						'desc' => '360° videobudka s obsluhou po dobu 2 hodin, neomezené množství videí, grafika, hudba a rekvizity, online galerie, doprava po Čechách zdarma.',
						'breakdown' => array(),
					),
					array(
						'id' => 'vb-3h', 'name' => 'Videobudka na 3h', 'price' => 11330,
						'desc' => '360° videobudka s obsluhou po dobu 3 hodin, neomezené množství videí, grafika, hudba a rekvizity, online galerie, doprava po Čechách zdarma.',
						'breakdown' => array(),
					),
					array(
						'id' => 'vb-4h', 'name' => 'Videobudka na 4h', 'price' => 12190,
						'desc' => '360° videobudka s obsluhou po dobu 4 hodin, neomezené množství videí, grafika, hudba a rekvizity, online galerie, doprava po Čechách zdarma.',
						'breakdown' => array(),
					),
				),
			),
			array(
				'id'           => 'vyzdoba',
				'name'         => 'Výzdoba',
				'type'         => 'custom',
				'defaultPrice' => 3000,
				'desc'         => 'Výzdoba prostoru na míru plesu — cena se stanovuje individuálně dle rozsahu a lokality akce.',
				'items'        => array(),
			),
		),
		'discountTiers' => array(
			array( 'id' => 'dt-2', 'minCount' => 2, 'type' => 'percent', 'value' => 5 ),
			array( 'id' => 'dt-3', 'minCount' => 3, 'type' => 'percent', 'value' => 10 ),
			array( 'id' => 'dt-4', 'minCount' => 4, 'type' => 'percent', 'value' => 15 ),
		),
	);
}

function pmc_get_config() {
	$raw = get_option( PMC_OPTION_KEY );
	if ( empty( $raw ) ) {
		return pmc_default_config();
	}
	$decoded = json_decode( $raw, true );
	if ( ! is_array( $decoded ) || empty( $decoded['sections'] ) ) {
		return pmc_default_config();
	}
	if ( ! isset( $decoded['discountTiers'] ) || ! is_array( $decoded['discountTiers'] ) ) {
		$decoded['discountTiers'] = array();
	}
	return $decoded;
}

register_activation_hook( __FILE__, function () {
	if ( false === get_option( PMC_OPTION_KEY ) ) {
		update_option( PMC_OPTION_KEY, wp_json_encode( pmc_default_config() ) );
	}
} );

/* ------------------------------------------------------------------ */
/*  REST API                                                           */
/* ------------------------------------------------------------------ */

add_action( 'rest_api_init', function () {
	register_rest_route( 'pmc/v1', '/config', array(
		array(
			'methods'             => 'GET',
			'callback'            => function () {
				return rest_ensure_response( pmc_get_config() );
			},
			'permission_callback' => '__return_true',
		),
		array(
			'methods'             => 'POST',
			'callback'            => 'pmc_save_config',
			'permission_callback' => function () {
				return current_user_can( 'manage_options' );
			},
		),
	) );
} );

function pmc_save_config( WP_REST_Request $request ) {
	$body = $request->get_json_params();

	if ( empty( $body ) || ! isset( $body['sections'] ) || ! is_array( $body['sections'] ) ) {
		return new WP_Error( 'pmc_invalid_data', 'Neplatná data ceníku.', array( 'status' => 400 ) );
	}

	$clean_sections = array();
	foreach ( $body['sections'] as $sec ) {
		$clean_sec = array(
			'id'   => sanitize_text_field( $sec['id'] ?? uniqid( 'sec_' ) ),
			'name' => sanitize_text_field( $sec['name'] ?? '' ),
			'type' => ( isset( $sec['type'] ) && 'custom' === $sec['type'] ) ? 'custom' : 'packages',
		);

		if ( 'custom' === $clean_sec['type'] ) {
			$clean_sec['defaultPrice'] = isset( $sec['defaultPrice'] ) ? floatval( $sec['defaultPrice'] ) : 0;
			$clean_sec['desc']         = sanitize_textarea_field( $sec['desc'] ?? '' );
			$clean_sec['items']        = array();
		} else {
			$items = array();
			if ( ! empty( $sec['items'] ) && is_array( $sec['items'] ) ) {
				foreach ( $sec['items'] as $item ) {
					$breakdown = array();
					if ( ! empty( $item['breakdown'] ) && is_array( $item['breakdown'] ) ) {
						foreach ( $item['breakdown'] as $b ) {
							$breakdown[] = array(
								'label'  => sanitize_text_field( $b['label'] ?? '' ),
								'amount' => floatval( $b['amount'] ?? 0 ),
							);
						}
					}
					$items[] = array(
						'id'        => sanitize_text_field( $item['id'] ?? uniqid( 'item_' ) ),
						'name'      => sanitize_text_field( $item['name'] ?? '' ),
						'price'     => floatval( $item['price'] ?? 0 ),
						'desc'      => sanitize_textarea_field( $item['desc'] ?? '' ),
						'breakdown' => $breakdown,
					);
				}
			}
			$clean_sec['items'] = $items;
		}

		$clean_sections[] = $clean_sec;
	}

	$clean_tiers = array();
	if ( ! empty( $body['discountTiers'] ) && is_array( $body['discountTiers'] ) ) {
		foreach ( $body['discountTiers'] as $t ) {
			$clean_tiers[] = array(
				'id'       => sanitize_text_field( $t['id'] ?? uniqid( 'tier_' ) ),
				'minCount' => max( 2, intval( $t['minCount'] ?? 2 ) ),
				'type'     => ( isset( $t['type'] ) && 'fixed' === $t['type'] ) ? 'fixed' : 'percent',
				'value'    => floatval( $t['value'] ?? 0 ),
			);
		}
	}

	$clean = array(
		'sections'      => $clean_sections,
		'discountTiers' => $clean_tiers,
	);

	update_option( PMC_OPTION_KEY, wp_json_encode( $clean ) );

	return rest_ensure_response( array( 'success' => true, 'config' => $clean ) );
}

/* ------------------------------------------------------------------ */
/*  Admin page                                                         */
/* ------------------------------------------------------------------ */

add_action( 'admin_menu', function () {
	add_menu_page(
		'Ceník plesy',
		'Ceník plesy',
		'manage_options',
		'pmc-pricing',
		'pmc_render_admin_page',
		'dashicons-tickets-alt',
		56
	);
} );

function pmc_render_admin_page() {
	echo '<div class="wrap"><h1 style="margin-bottom:18px;">Ceník — maturitní plesy</h1>';
	echo '<div id="pmc-admin-root" class="pmc-root" data-theme="day"></div></div>';
}

/* ------------------------------------------------------------------ */
/*  Shortcode                                                           */
/* ------------------------------------------------------------------ */

add_shortcode( 'prommemories_configurator', function ( $atts ) {
	static $instance = 0;
	$instance++;
	$id = 'pmc-public-root-' . $instance;

	wp_enqueue_style( 'pmc-style' );
	wp_enqueue_script( 'pmc-public' );

	return '<div id="' . esc_attr( $id ) . '" class="pmc-root pmc-public-instance" data-theme="night"></div>';
} );

/* ------------------------------------------------------------------ */
/*  Assets                                                              */
/* ------------------------------------------------------------------ */

add_action( 'wp_enqueue_scripts', function () {
	wp_register_style( 'pmc-style', PMC_PLUGIN_URL . 'assets/style.css', array(), PMC_VERSION );
	wp_register_script( 'pmc-public', PMC_PLUGIN_URL . 'assets/public.js', array(), PMC_VERSION, true );

	wp_localize_script( 'pmc-public', 'pmcPublicData', array(
		'config' => pmc_get_config(),
	) );
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( 'toplevel_page_pmc-pricing' !== $hook ) {
		return;
	}
	wp_enqueue_style( 'pmc-style', PMC_PLUGIN_URL . 'assets/style.css', array(), PMC_VERSION );
	wp_enqueue_script( 'pmc-admin', PMC_PLUGIN_URL . 'assets/admin.js', array(), PMC_VERSION, true );

	wp_localize_script( 'pmc-admin', 'pmcAdminData', array(
		'config'      => pmc_get_config(),
		'defaults'    => pmc_default_config(),
		'restUrl'     => esc_url_raw( rest_url( 'pmc/v1/config' ) ),
		'nonce'       => wp_create_nonce( 'wp_rest' ),
	) );
} );

/* ------------------------------------------------------------------ */
/*  Lightweight self-updater (GitHub JSON manifest, no WP.org needed)  */
/* ------------------------------------------------------------------ */

class PMC_Updater {

	private $plugin_file;
	private $slug;

	public function __construct( $plugin_file ) {
		$this->plugin_file = plugin_basename( $plugin_file );
		$this->slug        = dirname( $this->plugin_file );

		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_for_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_info' ), 20, 3 );
		add_filter( 'upgrader_source_selection', array( $this, 'fix_folder_name' ), 10, 4 );
	}

	private function get_remote_manifest() {
		$cached = get_transient( 'pmc_update_manifest' );
		if ( false !== $cached ) {
			return $cached;
		}
		$response = wp_remote_get( PMC_UPDATE_MANIFEST_URL, array( 'timeout' => 10 ) );
		if ( is_wp_error( $response ) || 200 !== wp_remote_retrieve_response_code( $response ) ) {
			return false;
		}
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $data['version'] ) || empty( $data['download_url'] ) ) {
			return false;
		}
		// Cache for 6 hours so we don't hammer GitHub on every admin page load.
		set_transient( 'pmc_update_manifest', $data, 6 * HOUR_IN_SECONDS );
		return $data;
	}

	public function check_for_update( $transient ) {
		if ( empty( $transient->checked ) ) {
			return $transient;
		}
		$remote = $this->get_remote_manifest();
		if ( ! $remote ) {
			return $transient;
		}
		if ( version_compare( PMC_VERSION, $remote['version'], '<' ) ) {
			$item = (object) array(
				'slug'        => $this->slug,
				'plugin'      => $this->plugin_file,
				'new_version' => $remote['version'],
				'url'         => isset( $remote['homepage'] ) ? $remote['homepage'] : '',
				'package'     => $remote['download_url'],
				'tested'      => isset( $remote['tested'] ) ? $remote['tested'] : '',
				'requires'    => isset( $remote['requires'] ) ? $remote['requires'] : '',
			);
			$transient->response[ $this->plugin_file ] = $item;
		}
		return $transient;
	}

	public function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || $args->slug !== $this->slug ) {
			return $result;
		}
		$remote = $this->get_remote_manifest();
		if ( ! $remote ) {
			return $result;
		}
		return (object) array(
			'name'          => 'PromMemories Konfigurátor cen',
			'slug'          => $this->slug,
			'version'       => $remote['version'],
			'download_link' => $remote['download_url'],
			'tested'        => isset( $remote['tested'] ) ? $remote['tested'] : '',
			'requires'      => isset( $remote['requires'] ) ? $remote['requires'] : '',
			'last_updated'  => isset( $remote['last_updated'] ) ? $remote['last_updated'] : '',
			'sections'      => isset( $remote['sections'] ) ? $remote['sections'] : array( 'description' => '' ),
		);
	}

	// GitHub zip downloads/archives unpack into a folder like "REPO-main";
	// rename it back to the plugin's own slug so WP overwrites the right folder.
	public function fix_folder_name( $source, $remote_source, $upgrader, $hook_extra ) {
		global $wp_filesystem;

		if ( empty( $hook_extra['plugin'] ) || $hook_extra['plugin'] !== $this->plugin_file ) {
			return $source;
		}
		$desired = trailingslashit( $remote_source ) . $this->slug . '/';
		if ( trailingslashit( $source ) !== $desired && $wp_filesystem->move( $source, $desired ) ) {
			return $desired;
		}
		return $source;
	}
}

new PMC_Updater( __FILE__ );
